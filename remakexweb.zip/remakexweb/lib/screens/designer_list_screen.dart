import 'package:flutter/material.dart';

class DesignerListScreen extends StatefulWidget {
  const DesignerListScreen({super.key});

  @override
  State<DesignerListScreen> createState() => _DesignerListScreenState();
}

class _DesignerListScreenState extends State<DesignerListScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  String _selectedSpecialty = 'All';

  final List<String> _specialties = [
    'All',
    'Furniture Redesign',
    'Fashion Upcycling',
    'Musical Instruments',
    'Home Decor',
    'Industrial Design',
  ];

  final List<Map<String, dynamic>> _allDesigners = [
    {
      'name': 'Alve Rahman',
      'specialty': 'Furniture Redesign',
      'rating': 4.8,
      'projects': 45,
      'description': 'Specializing in transforming old furniture into modern masterpieces',
      'availability': 'Available',
    },
    {
      'name': 'Noman Ali',
      'specialty': 'Fashion Upcycling',
      'rating': 4.9,
      'projects': 67,
      'description': 'Expert in sustainable fashion and clothing transformation',
      'availability': 'Busy',
    },
    {
      'name': 'Siam Ahmed',
      'specialty': 'Musical Instruments',
      'rating': 4.7,
      'projects': 38,
      'description': 'Creative designer specializing in musical instrument upcycling',
      'availability': 'Available',
    },
    {
      'name': 'Omio Hassan',
      'specialty': 'Home Decor',
      'rating': 4.9,
      'projects': 52,
      'description': 'Transforming everyday items into beautiful home decorations',
      'availability': 'Available',
    },
    {
      'name': 'Jahid Hasan',
      'specialty': 'Industrial Design',
      'rating': 4.8,
      'projects': 41,
      'description': 'Specialized in industrial and mechanical item transformations',
      'availability': 'Busy',
    },
    // Add more designers...
  ];

  List<Map<String, dynamic>> get _filteredDesigners {
    return _allDesigners.where((designer) {
      final matchesSearch = designer['name'].toString().toLowerCase().contains(_searchQuery.toLowerCase()) ||
          designer['description'].toString().toLowerCase().contains(_searchQuery.toLowerCase()) ||
          designer['specialty'].toString().toLowerCase().contains(_searchQuery.toLowerCase());
      
      final matchesSpecialty = _selectedSpecialty == 'All' || designer['specialty'] == _selectedSpecialty;
      
      return matchesSearch && matchesSpecialty;
    }).toList();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Our Designers'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'Search designers...',
                    prefixIcon: const Icon(Icons.search),
                    suffixIcon: _searchQuery.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear),
                            onPressed: () {
                              setState(() {
                                _searchController.clear();
                                _searchQuery = '';
                              });
                            },
                          )
                        : null,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    contentPadding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  onChanged: (value) {
                    setState(() {
                      _searchQuery = value;
                    });
                  },
                ),
                const SizedBox(height: 16),
                SizedBox(
                  height: 40,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: _specialties.length,
                    itemBuilder: (context, index) {
                      final specialty = _specialties[index];
                      return Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: ChoiceChip(
                          label: Text(specialty),
                          selected: _selectedSpecialty == specialty,
                          onSelected: (selected) {
                            setState(() {
                              _selectedSpecialty = specialty;
                            });
                          },
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: _filteredDesigners.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.search_off,
                          size: 64,
                          color: Colors.grey[400],
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'No designers found',
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _filteredDesigners.length,
                    itemBuilder: (context, index) {
                      final designer = _filteredDesigners[index];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: InkWell(
                          onTap: () {
                            // TODO: Navigate to designer profile
                          },
                          borderRadius: BorderRadius.circular(16),
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Row(
                              children: [
                                CircleAvatar(
                                  radius: 40,
                                  backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                                  child: Text(
                                    (designer['name'] as String).substring(0, 1),
                                    style: TextStyle(
                                      fontSize: 32,
                                      fontWeight: FontWeight.bold,
                                      color: Theme.of(context).colorScheme.primary,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 16),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            designer['name'] as String,
                                            style: const TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 18,
                                            ),
                                          ),
                                          Container(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 8,
                                              vertical: 4,
                                            ),
                                            decoration: BoxDecoration(
                                              color: designer['availability'] == 'Available'
                                                  ? Colors.green
                                                  : Colors.orange,
                                              borderRadius: BorderRadius.circular(12),
                                            ),
                                            child: Text(
                                              designer['availability'] as String,
                                              style: const TextStyle(
                                                color: Colors.white,
                                                fontSize: 12,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        designer['specialty'] as String,
                                        style: TextStyle(
                                          color: Theme.of(context).colorScheme.primary,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        designer['description'] as String,
                                        style: TextStyle(
                                          color: Colors.grey[600],
                                          fontSize: 14,
                                        ),
                                      ),
                                      const SizedBox(height: 8),
                                      Row(
                                        children: [
                                          Icon(
                                            Icons.star,
                                            size: 16,
                                            color: Colors.amber,
                                          ),
                                          Text(
                                            ' ${designer['rating']} • ${designer['projects']} projects',
                                            style: TextStyle(
                                              color: Colors.grey[600],
                                              fontSize: 14,
                                            ),
                                          ),
                                          const Spacer(),
                                          TextButton(
                                            onPressed: () {
                                              // TODO: Implement hire action
                                            },
                                            child: const Text('Hire Now'),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
} 