import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_model.dart';

class AuthService {
  static const String _usersKey = 'users';
  static const String _currentUserKey = 'currentUser';

  // Initialize shared preferences with default admin account
  Future<void> initializeApp() async {
    final prefs = await SharedPreferences.getInstance();
    if (!prefs.containsKey(_usersKey)) {
      // Create default admin account if no users exist
      final adminUser = User(
        name: 'Admin',
        email: 'admin@remakex.com',
        password: 'admin123',
      );
      await prefs.setStringList(_usersKey, [jsonEncode(adminUser.toJson())]);
    }
  }

  // Get all users
  Future<List<User>> getUsers() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final usersJson = prefs.getStringList(_usersKey) ?? [];
      return usersJson
          .map((userStr) => User.fromJson(jsonDecode(userStr)))
          .toList();
    } catch (e) {
      print('Error getting users: $e');
      return [];
    }
  }

  // Register new user
  Future<bool> register(User user) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final users = await getUsers();

      // Check if email already exists
      if (users.any((u) => u.email == user.email)) {
        return false;
      }

      // Add new user
      users.add(user);
      
      // Save updated users list
      final userJsonList = users.map((u) => jsonEncode(u.toJson())).toList();
      await prefs.setStringList(_usersKey, userJsonList);
      
      // Automatically login after registration
      await prefs.setString(_currentUserKey, jsonEncode(user.toJson()));
      
      return true;
    } catch (e) {
      print('Error registering user: $e');
      return false;
    }
  }

  // Login user
  Future<User?> login(String email, String password) async {
    try {
      final users = await getUsers();
      final user = users.firstWhere(
        (u) => u.email == email && u.password == password,
      );

      // Save current user
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_currentUserKey, jsonEncode(user.toJson()));
      
      return user;
    } catch (e) {
      print('Error logging in: $e');
      return null;
    }
  }

  // Get current user
  Future<User?> getCurrentUser() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final userJson = prefs.getString(_currentUserKey);
      if (userJson == null) return null;
      return User.fromJson(jsonDecode(userJson));
    } catch (e) {
      print('Error getting current user: $e');
      return null;
    }
  }

  // Logout user
  Future<void> logout() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_currentUserKey);
    } catch (e) {
      print('Error logging out: $e');
    }
  }

  // Delete user account
  Future<bool> deleteAccount(String email) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final users = await getUsers();
      
      users.removeWhere((u) => u.email == email);
      
      final userJsonList = users.map((u) => jsonEncode(u.toJson())).toList();
      await prefs.setStringList(_usersKey, userJsonList);
      
      return true;
    } catch (e) {
      print('Error deleting account: $e');
      return false;
    }
  }

  // Update user profile
  Future<bool> updateProfile(User updatedUser) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final users = await getUsers();
      
      final index = users.indexWhere((u) => u.email == updatedUser.email);
      if (index != -1) {
        users[index] = updatedUser;
        
        final userJsonList = users.map((u) => jsonEncode(u.toJson())).toList();
        await prefs.setStringList(_usersKey, userJsonList);
        
        // Update current user if it's the same user
        final currentUser = await getCurrentUser();
        if (currentUser?.email == updatedUser.email) {
          await prefs.setString(_currentUserKey, jsonEncode(updatedUser.toJson()));
        }
        
        return true;
      }
      return false;
    } catch (e) {
      print('Error updating profile: $e');
      return false;
    }
  }
} 